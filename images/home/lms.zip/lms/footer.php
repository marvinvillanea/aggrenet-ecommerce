<center>
		<footer>
		
		<p>CHMSC M-Learning Copyright 2013</p>
			<!-- <p>Programmed by: John Kevin Lorayna BSIS 4-A</p> -->
		</footer>
</center>

